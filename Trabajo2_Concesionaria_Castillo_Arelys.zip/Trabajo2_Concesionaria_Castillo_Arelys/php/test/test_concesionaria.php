<?php ini_set("display_errors","1");?>
<?php
    require_once "../entities/vehiculo.php";
    require_once "../entities/auto.php";
    require_once "../entities/moto.php";
    require_once "../entities/concesionaria.php";
    require_once "../interfaces/I_concesionaria.php";
    
echo "<h1>Test Concesionaria</h1>";
echo "<h2>---Test Vehiculos---</h2>"; 

 $vehiculos = new Concesionaria();                          //Creación de una instancia de la clase Concesionaria
 
 $vehiculos->mostrarVehiculos();                            //Muestra de la lista de vehiculos

echo "============================<br><br>"; 
    
$caro= new Concesionaria();
echo  $caro->mostrar_vehiculo_mas_caro();                       //Vehiculo más caro       
$barato= new Concesionaria();
echo $barato->mostrar_vehiculo_mas_barato();                    //Vehiculo más barato   
$letra= new Concesionaria();
echo $letra->mostrar_vehiculo_modelo_letra_Y();                 //Vehículo que contiene en el modelo la letra ‘Y’ 

echo "<br><br>============================<br><br>";     

$desc= new Concesionaria();
echo $desc->ordenar_vehiculos_precio_desc();            //Vehículos ordenados por precio de mayor a menor    

echo "<br>============================<br><br>";

$orden_natural=new Concesionaria();
echo $orden_natural->ordenar_vehiculos_orden_natural(); //Vehículos ordenados por orden natural (marca, modelo, precio)
    
?>