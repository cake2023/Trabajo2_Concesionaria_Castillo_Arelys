<?php
abstract class Vehiculo{
    private $marca;
    private $modelo;
    private $precio;
    private $puertas;
    private $cilindrada;

    public function __construct(string $marca, string $modelo,float $precio){
        $this->marca=$marca;
        $this->modelo=$modelo;
        $this->precio=$precio;
    }

    public function __tostring(){
        return "Marca: ".$this->marca."// Modelo: ".$this->modelo."// Precio: $".$this->precio." ";
    }
}
?>