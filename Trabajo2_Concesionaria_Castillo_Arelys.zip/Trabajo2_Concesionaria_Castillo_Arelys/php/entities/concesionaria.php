<?php
require_once "../interfaces/I_concesionaria.php";
class Concesionaria implements I_Concesionaria {
    private array $listaVehiculos;
    public function __construct(){
        $this->listaVehiculos= array(
            new Auto("Peugeot","206",4,200000 ),
            new Moto("Honda","Titan","125c",60000 ),
            new Auto("Peugeot","208",5,250000 ),
            new Moto("Yamaha","YBR","160c",80500.50 )
        );
    }
    
    public function mostrarVehiculos(): void {
        foreach ($this->listaVehiculos as $value) {
            echo $value."<br>";
        }
    }
    
    public function mostrar_vehiculo_mas_caro(): string {
        $mayor= $this->listaVehiculos[0];
        foreach ($this->listaVehiculos as $valor){
            if ($valor->precio > $mayor->precio) {
                $mayor = $valor;
            }
        }
        return "Vehículo más caro: " .$mayor->marca." ".$mayor->modelo."<br>";
    }
    
    public function mostrar_vehiculo_mas_barato(): string{
        $menor= $this->listaVehiculos[0];
        foreach ($this->listaVehiculos as $valor){
            if ($valor->precio < $menor->precio){
                $menor = $valor;
            }
        }
        return "Vehículo más barato: " .$menor->marca." ".$menor->modelo."<br>";
    }
   
    public function mostrar_vehiculo_modelo_letra_Y(): string{
        $letra= $this->listaVehiculos[0];
        foreach ($this->listaVehiculos as $valor){
            if ($valor->modelo == 'Y'){
                $letra= $valor->modelo;
            }
        }
        return " Vehículo que contiene en el modelo la letra ‘Y’: "
                .$valor->marca." ".$valor->modelo." $".$valor->precio;
    }

    function ordenar_vehiculos_precio_desc(){
        $listaVehiculos= array(
            "Peugeot 206"=>200000,
            "Honda Titan"=>60000,
            "Peugeot 208"=>250000,
            "Yamaha YBR"=>80500.50
        );
        
        arsort($listaVehiculos);
        echo " Vehículos ordenados por precio de mayor a menor:<br>";
        foreach ($listaVehiculos as $key => $value) {
            echo $key."<br>";
        }  
    }
  
    function ordenar_vehiculos_orden_natural(){
        usort($this->listaVehiculos, function($a,$b){
            return strcmp($a->marca,$b->marca);}
        );
                          
        for($i=0;$i<count($this->listaVehiculos); $i++){
            echo $this->listaVehiculos[$i]."<br>";
        }      
    }
    
}
?>