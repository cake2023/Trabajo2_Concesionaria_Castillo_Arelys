<?php
class Auto extends Vehiculo{
    private $puertas;
    public function __construct(public string $marca,public string $modelo,
                                int $puertas,public float $precio){

        parent::__construct( $marca,$modelo, $precio);
        $this->puertas=$puertas;
    }

    public function __tostring(){
        return "Marca: ".$this->marca." // Modelo: ".$this->modelo." // Puertas: ".$this->puertas.
        " // Precio: $".number_format($this->precio,2,',','.');
    }

    }
?>