<?php
class Moto extends Vehiculo{
    private $cilindrada;
    public function __construct(public string $marca,public string $modelo,
                                string $cilindrada, public float $precio){

        parent::__construct( $marca,$modelo, $precio);
        $this->cilindrada=$cilindrada;
    }

    public function __tostring(){
        return "Marca: ".$this->marca." // Modelo: ".$this->modelo.
        " // Cilindrada: ".$this->cilindrada." // Precio: $"
        .number_format($this->precio,2,',','.');
    }

    }
?>