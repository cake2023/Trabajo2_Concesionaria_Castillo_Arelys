<?php
interface I_Concesionaria{
    function mostrar_vehiculo_mas_caro();
    function mostrar_vehiculo_mas_barato();
    function mostrar_vehiculo_modelo_letra_Y(): string;
    function ordenar_vehiculos_precio_desc();
    function ordenar_vehiculos_orden_natural();
}
?>